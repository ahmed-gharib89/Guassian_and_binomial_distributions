from setuptools import setup

setup(name = 'gharib_probability',
      version = '0.1',
      description = 'Gaussian and Binomial distributions',
      packages= ['gharib_probability'],
      author = 'Ahmed Gharib',
      author_email = 'a.gharib89@yahoo.com',
      zip_safe = False)
